
import React from 'react';

const Weather = (props)=>{
    
    return (
        <div className= "container">
            <div className="cards">
            <h1>Weather App</h1>
            <h6>Accra,Ghana</h6>
            <h6>08-09-2020</h6>
            <h5 className="py-4">
                
                <i className="wi wi-day-sunny display-1"></i>
                <h1 className="py-2">25&deg;C</h1>
                
            
            </h5>

        </div>
        </div>
        
    
               

    );
};

export default Weather;
            
    